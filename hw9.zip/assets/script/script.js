$(document).ready(function() {


	$("#s1").click(function(){
		$("#o1").fadeIn(200);
		});

	$("#s2").click(function(){
		$(".outfit").hide();
		$("#o2").fadeIn(200);
		});

	$("#s3").click(function(){
		$(".outfit").hide();	
		$("#o3").fadeIn(200);
		});

	$("#s4").click(function(){
		$(".outfit").hide();
		$("#o4").fadeIn(200);
		});

	$("#s5").click(function(){
		$(".outfit").hide();
		$("#o5").fadeIn(200);
		});
	$("#strip-button").click(function(){
		$(".outfit").hide();
	});

});
